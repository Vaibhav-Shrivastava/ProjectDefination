var main_filedata = {
    "lib\\PrjDigitalTwin\\DigTwinServices.xsodata": {
        "container": "xsjs",
        "fileIndex": 0
    },
    "src\\PrjDigitalTwin\\Tables.hdbcds": {
        "container": "db",
        "fileIndex": 1
    },
    "src\\PrjDigitalTwin\\DataLoads\\Data.csv": {
        "container": "db",
        "fileIndex": 2
    },
    "src\\PrjDigitalTwin\\DataLoads\\importdata.hdbtabledata": {
        "container": "db",
        "fileIndex": 3
    }
};