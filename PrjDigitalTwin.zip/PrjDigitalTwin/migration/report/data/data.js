var main_data = {
    "sum": [
        {
            "name": "total",
            "number": 8
        },
        {
            "name": "xsjs",
            "number": 1,
            "detail": {
                ".xsodata": 1
            }
        },
        {
            "name": "db",
            "number": 4,
            "detail": {
                ".hdbschema": 1,
                ".hdbdd": 1,
                ".csv": 1,
                ".hdbti": 1
            }
        },
        {
            "name": "todo",
            "number": 1,
            "detail": {
                ".xsaccess": 1
            }
        },
        {
            "name": "delete",
            "number": 1,
            "detail": {
                ".xsapp": 1
            }
        },
        {
            "name": "unknown",
            "detail": {
                ".sql": 1
            },
            "number": 1
        }
    ],
    "errors": {
        "number": 0,
        "list": []
    },
    "warnings": {
        "number": 4,
        "list": [
            {
                "type": "WARNING",
                "message": [
                    "Unknown file type. Migrate the file manually if necessary."
                ],
                "description": "The migration assistant does not know the object type of this object. If this file is related to your application and still needed, copy it to the appropriate container (web or xsjs).",
                "category": "TODO",
                "id": "TODO_4",
                "file": "migration\\orig-src\\PrjDigitalTwin\\GrantSchemaAccess.sql"
            },
            {
                "type": "WARNING",
                "message": [
                    "Features in xsaccess can only be partially migrated to new XS Advanced security concept (xsjs/xs-app.json). Check the migration guide for further detail."
                ],
                "description": "For more information, see the Security Migration Guide",
                "category": "SECURITY",
                "id": "SECURITY_2",
                "file": "migration\\orig-src\\PrjDigitalTwin\\.xsaccess"
            },
            {
                "type": "WARNING",
                "message": [
                    "The behavior of distinction of empty and null values has changed."
                ],
                "description": "The default behavior of HDI equals the hdbti setting distinguishEmptyFromNull=true. The processed hdbti file did not specify this setting or set it to false. This could now lead to different behavior of the generated hdbtabledata file if your CSV files contain two subsequent delimEnclosing characters (as specified in your .hdbti or double quotes by default). HDI will now interpret this as an empty string value instead of null. If this is OK for you, you can ignore this warning. If not, please check your CSV files for such cases and remove the delimiters from values that should be interpreted as null.",
                "category": "HDI",
                "id": "HDI_8",
                "file": "migration\\orig-src\\PrjDigitalTwin\\DataLoads\\importdata.hdbti"
            },
            {
                "type": "WARNING",
                "message": [
                    "Application does not have any role or privileges defined. Therefore we could not generate xs-security.json and default_access_role.hdbrole for you."
                ],
                "category": "SECURITY",
                "id": "SECURITY_1",
                "file": ""
            }
        ]
    },
    "infos": {
        "number": 2,
        "list": [
            {
                "type": "INFO",
                "message": [
                    "The {0} file is no longer needed in XS Advanced projects.",
                    ".xsapp"
                ],
                "description": "The object type has not been migrated and is no longer relevant for XS Advanced projects. There is no loss of functionality.",
                "category": "DELETE",
                "id": "DELETE_1",
                "file": "migration\\orig-src\\PrjDigitalTwin\\.xsapp"
            },
            {
                "type": "INFO",
                "message": [
                    "The {0} file is no longer needed in XS Advanced projects.",
                    ".hdbschema"
                ],
                "description": "The object type has not been migrated and is no longer relevant for XS Advanced projects. There is no loss of functionality.",
                "category": "DELETE",
                "id": "DELETE_1",
                "file": "migration\\orig-src\\PrjDigitalTwin\\DIGTWIN.hdbschema"
            }
        ]
    },
    "steps": [
        {
            "priority": 4,
            "always-shown": true,
            "name": "Migration of Security Concept Required",
            "desc": "The security concept has changed with XS Advanced and is incompatible with XS Classic. Manual migration steps are required in order to complete the migration of this application to XS Advanced. <br>For information about the XS Advanced security concept read the XS Advanced Migration Guide.",
            "link": {
                "info": "description",
                "url": "undefined#security"
            },
            "messages": {
                "WARNING": [
                    {
                        "type": "WARNING",
                        "message": [
                            "Features in xsaccess can only be partially migrated to new XS Advanced security concept (xsjs/xs-app.json). Check the migration guide for further detail."
                        ],
                        "description": "For more information, see the Security Migration Guide",
                        "category": "SECURITY",
                        "id": "SECURITY_2",
                        "file": "migration\\orig-src\\PrjDigitalTwin\\.xsaccess"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Application does not have any role or privileges defined. Therefore we could not generate xs-security.json and default_access_role.hdbrole for you."
                        ],
                        "category": "SECURITY",
                        "id": "SECURITY_1",
                        "file": ""
                    }
                ]
            },
            "list": [
                {
                    "text": "WARNING",
                    "value": 2
                }
            ]
        },
        {
            "priority": 6,
            "name": "Database Artifacts",
            "desc": "Migration of database artifacts has raised the following messages.",
            "link": {
                "info": "description",
                "url": "undefined#database-artifacts"
            },
            "messages": {
                "WARNING": [
                    {
                        "type": "WARNING",
                        "message": [
                            "The behavior of distinction of empty and null values has changed."
                        ],
                        "description": "The default behavior of HDI equals the hdbti setting distinguishEmptyFromNull=true. The processed hdbti file did not specify this setting or set it to false. This could now lead to different behavior of the generated hdbtabledata file if your CSV files contain two subsequent delimEnclosing characters (as specified in your .hdbti or double quotes by default). HDI will now interpret this as an empty string value instead of null. If this is OK for you, you can ignore this warning. If not, please check your CSV files for such cases and remove the delimiters from values that should be interpreted as null.",
                        "category": "HDI",
                        "id": "HDI_8",
                        "file": "migration\\orig-src\\PrjDigitalTwin\\DataLoads\\importdata.hdbti"
                    }
                ]
            },
            "list": [
                {
                    "text": "WARNING",
                    "value": 1
                }
            ]
        },
        {
            "priority": 9,
            "name": "Unknown File Types or File Content",
            "desc": "The XS migration assistant was not able to identify these file types. You must decide whether these objects are still relevant, and copy them into the appropriate module directory if needed.",
            "link": {
                "info": "description",
                "url": "undefined#todo"
            },
            "messages": {
                "WARNING": [
                    {
                        "type": "WARNING",
                        "message": [
                            "Unknown file type. Migrate the file manually if necessary."
                        ],
                        "description": "The migration assistant does not know the object type of this object. If this file is related to your application and still needed, copy it to the appropriate container (web or xsjs).",
                        "category": "TODO",
                        "id": "TODO_4",
                        "file": "migration\\orig-src\\PrjDigitalTwin\\GrantSchemaAccess.sql"
                    }
                ]
            },
            "list": [
                {
                    "text": "WARNING",
                    "value": 1
                }
            ]
        },
        {
            "priority": 11,
            "name": "Objects Which Have Not Been Migrated",
            "desc": "The following objects have not been migrated because they are either not relevant anymore or have been successfully migrated to another object type.",
            "link": {
                "info": "description",
                "url": "undefined#delete"
            },
            "messages": {
                "INFO": [
                    {
                        "type": "INFO",
                        "message": [
                            "The {0} file is no longer needed in XS Advanced projects.",
                            ".xsapp"
                        ],
                        "description": "The object type has not been migrated and is no longer relevant for XS Advanced projects. There is no loss of functionality.",
                        "category": "DELETE",
                        "id": "DELETE_1",
                        "file": "migration\\orig-src\\PrjDigitalTwin\\.xsapp"
                    },
                    {
                        "type": "INFO",
                        "message": [
                            "The {0} file is no longer needed in XS Advanced projects.",
                            ".hdbschema"
                        ],
                        "description": "The object type has not been migrated and is no longer relevant for XS Advanced projects. There is no loss of functionality.",
                        "category": "DELETE",
                        "id": "DELETE_1",
                        "file": "migration\\orig-src\\PrjDigitalTwin\\DIGTWIN.hdbschema"
                    }
                ]
            },
            "list": [
                {
                    "text": "INFO",
                    "value": 2
                }
            ]
        }
    ],
    "task": {
        "dus": [],
        "packages": [
            "PrjDigitalTwin",
            "PrjDigitalTwin.DataLoads"
        ]
    },
    "project": {
        "name": "WIPRO_DU",
        "vendor": "No-vendor",
        "version": "0",
        "description": ""
    },
    "cmdline": "--h \"false\" --help \"false\" --generate-manifests \"false\" --zip \"false\" --hta \"false\" --generate-providers \"false\" --unhide-hidden-columns \"false\" --generate-local-slash-synonyms \"false\" --integrated-synonymtargets \"false\" --name \"WIPRO_DU\" --packages \"PrjDigitalTwin\" --target-dir \"PrjDigitalTwin\"",
    "isoTime": "2021-03-03T05:16:06.393Z",
    "mig-tool-version": "1.0.25",
    "system": {
        "host": "localhost",
        "port": "30115",
        "user": "HANA_ADM",
        "sid": "IIB",
        "hana_version": "1.00.122.34.1611791097"
    }
};