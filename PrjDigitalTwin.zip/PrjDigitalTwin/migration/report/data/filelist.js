var main_filelist = [
    {
        "name": "xsjs\\lib\\PrjDigitalTwin\\DigTwinServices.xsodata",
        "pkgOnlyName": "\\PrjDigitalTwin\\DigTwinServices.xsodata",
        "ext": "xsodata",
        "container": "xsjs",
        "index": 0
    },
    {
        "name": "db\\src\\PrjDigitalTwin\\Tables.hdbcds",
        "pkgOnlyName": "\\PrjDigitalTwin\\Tables.hdbcds",
        "ext": "hdbcds",
        "container": "db",
        "index": 1
    },
    {
        "name": "db\\src\\PrjDigitalTwin\\DataLoads\\Data.csv",
        "pkgOnlyName": "\\PrjDigitalTwin\\DataLoads\\Data.csv",
        "ext": "csv",
        "container": "db",
        "index": 2
    },
    {
        "name": "db\\src\\PrjDigitalTwin\\DataLoads\\importdata.hdbtabledata",
        "pkgOnlyName": "\\PrjDigitalTwin\\DataLoads\\importdata.hdbtabledata",
        "ext": "hdbtabledata",
        "container": "db",
        "index": 3
    }
];